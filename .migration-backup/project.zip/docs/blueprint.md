# **App Name**: QualityCheck

## Core Features:

- Role-Based Login: Role-Based Login: Login page for inspectors and managers, role-based.
- Item Check Form: Item Check Form: Display form with all data input fields
- SPC Chart View: SPC Chart View: View SPC Chart for current check
- AI-Powered Issue Spotting: AI-Powered Issue Spotting: Based on current measurments - highlight what is wrong in the input to inform quality inspectors; this feature uses an LLM tool to determine.

## Style Guidelines:

- Primary color: Light grey-blue (#8FB2C2) to give a precise, professional, reliable impression.
- Background color: Off-white (#F4F6F7), very desaturated to almost be perceived as a light shade of gray, creates a clear canvas for content.
- Accent color: Muted teal (#468787) to draw attention to important actions and interactive elements.
- Font: 'Inter' (sans-serif) for a modern, machined, objective, and neutral aesthetic; good for both headlines and body text.
- Use simple, clear icons for navigation and interactive elements.
- Clean, structured layout with clear visual hierarchy. Prioritize data visibility and easy navigation.
- Subtle transitions and loading animations to improve user experience without being distracting.